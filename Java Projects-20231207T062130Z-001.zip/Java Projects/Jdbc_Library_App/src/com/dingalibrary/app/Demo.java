package com.dingalibrary.app;

public class Demo {
	static {
		System.out.println("Demo is loaded...");
	}
}
