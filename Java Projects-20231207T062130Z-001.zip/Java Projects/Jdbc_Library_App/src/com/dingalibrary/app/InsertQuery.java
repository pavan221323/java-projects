package com.dingalibrary.app;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;

/*
 * 1) Load and register driver(Optional)
 * 2) Get connection
 * 3) Create statement and execute query
 * 4) close the connection
 */
public class InsertQuery {
	public static void main(String[] args) {
		try {
			Connection connection = DriverManager
					.getConnection("jdbc:mysql://localhost:3306/dinga", "root", "dinga");
			Statement statement = connection.createStatement() ;
			String q = "Insert into books values(104,'JS','Tamil',250)" ;
			int res = statement.executeUpdate(q) ;
			System.out.println( res + " is added");
			
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
		
		
	}

}
