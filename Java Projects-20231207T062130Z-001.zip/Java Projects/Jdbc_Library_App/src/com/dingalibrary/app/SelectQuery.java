package com.dingalibrary.app;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class SelectQuery {
	public static void main(String[] args) {
		Connection connection = null;
		Statement statement = null;
		ResultSet rs = null;
//			 load and register Driver class
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
//			Get connection
			connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/dinga", "root", "dinga");
//			Create statement 
			String query = "Select * from books";
			statement = connection.createStatement();
//			Execute query
			rs = statement.executeQuery(query);
			boolean flag = true;
			while (rs.next()) {
				System.out.println("Bookl Id :: " + rs.getInt(1));
				System.out.println("Book Name :: " + rs.getString(2));
				System.out.println("Book author :: " + rs.getString(3));
				System.out.println("Book Price :: " + rs.getDouble(4));
				System.out.println("______________________________________");
				flag = false;
			}
			if (flag) {
				System.out.println("No data available in table");
			}

		} catch (SQLException | ClassNotFoundException e) {
			e.printStackTrace();
		} finally {
			try {
				if (connection != null) {
					connection.close();
				}
				if( statement != null ) {
					statement.close() ;
				}
				if( rs != null ) {
					rs.close() ;
				}
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
	}

}
